library(testthat)
library(robis)

test_check("robis")
