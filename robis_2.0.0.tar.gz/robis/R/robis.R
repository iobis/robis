#' robis: R client for the OBIS API
#'
#' Work in progress
#'
#' @docType package
#' @name robis
#' @import dplyr httr jsonlite leaflet ggplot2
NULL
